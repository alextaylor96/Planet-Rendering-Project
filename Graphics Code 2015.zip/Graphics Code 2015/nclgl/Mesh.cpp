#include "Mesh.h"
#include <map>
#include <array>
#include "Noise.h"

#define X 0.525731112119133606f 
#define Z 0.850650808352039932f
#define N 0.0f

Mesh::Mesh(void) {
	for (int i = 0; i < MAX_BUFFER; ++i) {
		bufferObject[i] = 0;
	}
	glGenVertexArrays(1, &arrayObject);
	vertices = NULL;
	indices = NULL;
	colours = NULL;
	normals = NULL;
	numVertices = 0;
	numIndices = 0;
	type = GL_TRIANGLES;
	texture = 0;
	textureCoords = NULL;
}

Mesh ::~Mesh(void) {
	glDeleteVertexArrays(1, &arrayObject);
	glDeleteBuffers(MAX_BUFFER, bufferObject);
	delete[] vertices;
	delete[] indices;
	delete[] colours;
	delete[] normals;
	glDeleteTextures(1, &texture);
	delete[] textureCoords;
}

void   Mesh::GenerateNormals() {
	if (!normals) {
		normals = new  Vector3[numVertices];

	}
	for (GLuint i = 0; i < numVertices; ++i) {
		normals[i] = Vector3();

	}
	if (indices) {
		for (GLuint i = 0; i < numIndices; i += 3) {
			unsigned  int a = indices[i];
			unsigned  int b = indices[i + 1];
			unsigned  int c = indices[i + 2];

			Vector3  normal = Vector3::Cross(
				(vertices[b] - vertices[a]), (vertices[c] - vertices[a]));

			normals[a] += normal;
			normals[b] += normal;
			normals[c] += normal;

		}

	}
	else {
		for (GLuint i = 0; i < numVertices; i += 3) {
			Vector3 &a = vertices[i];
			Vector3 &b = vertices[i + 1];
			Vector3 &c = vertices[i + 2];

			Vector3  normal = Vector3::Cross(b - a, c - a);

			normals[i] = normal;
			normals[i + 1] = normal;
			normals[i + 2] = normal;

		}

	}

	for (GLuint i = 0; i < numVertices; ++i) {
		normals[i].Normalise();

	}

}

Mesh* Mesh::GenerateTriangle() {
	Mesh*m = new  Mesh();
	m->numVertices = 3;
	m->vertices = new  Vector3[m->numVertices];
	m->vertices[0] = Vector3(0.0f, 0.5f, 0.0f);
	m->vertices[1] = Vector3(0.5f, -0.5f, 0.0f);
	m->vertices[2] = Vector3(-0.5f, -0.5f, 0.0f);

	m->textureCoords = new  Vector2[m->numVertices];
	m->textureCoords[0] = Vector2(0.5f, 0.0f);
	m->textureCoords[1] = Vector2(1.0f, 1.0f);
	m->textureCoords[2] = Vector2(0.0f, 1.0f);

	m->colours = new  Vector4[m->numVertices];
	m->colours[0] = Vector4(1.0f, 0.0f, 0.0f, 1.0f);
	m->colours[1] = Vector4(0.0f, 1.0f, 0.0f, 1.0f);
	m->colours[2] = Vector4(0.0f, 0.0f, 1.0f, 1.0f);

	
	m->BufferData();
	return m;
}


Mesh* Mesh::GenerateTriangleStrips() {
	Mesh*m = new  Mesh();
	
	m->numVertices = 4;
	m->vertices = new  Vector3[m->numVertices];

	m->vertices[0] = Vector3(0.0f, 0.5f, 0.0f);
	m->vertices[1] = Vector3(0.0f, -0.5f, 0.0f);
	m->vertices[2] = Vector3(-0.5f, -0.5f, 0.0f);
	m->vertices[3] = Vector3(-1.0f, -1.0f, 0.0f);

	
	m->colours = new  Vector4[m->numVertices];
	m->colours[0] = Vector4(1.0f, 0.0f, 0.0f, 1.0f);
	m->colours[1] = Vector4(0.0f, 1.0f, 0.0f, 1.0f);
	m->colours[2] = Vector4(0.0f, 0.0f, 1.0f, 1.0f);
	m->colours[3] = Vector4(0.0f, 0.0f, 1.0f, 1.0f);
	
	
	m->BufferData();
	return m;
}



void   Mesh::BufferData() {
	glBindVertexArray(arrayObject);
	glGenBuffers(1, &bufferObject[VERTEX_BUFFER]);
	glBindBuffer(GL_ARRAY_BUFFER, bufferObject[VERTEX_BUFFER]);
	glBufferData(GL_ARRAY_BUFFER, numVertices * sizeof(Vector3), vertices, GL_STATIC_DRAW);
	glVertexAttribPointer(VERTEX_BUFFER, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(VERTEX_BUFFER);

	if (textureCoords) { 
		glGenBuffers(1, &bufferObject[TEXTURE_BUFFER]);
		glBindBuffer(GL_ARRAY_BUFFER, bufferObject[TEXTURE_BUFFER]);
		glBufferData(GL_ARRAY_BUFFER, numVertices * sizeof(Vector2), textureCoords, GL_STATIC_DRAW);
		glVertexAttribPointer(TEXTURE_BUFFER, 2, GL_FLOAT, GL_FALSE, 0, 0);
		glEnableVertexAttribArray(TEXTURE_BUFFER);
	}

	if (indices) {
		glGenBuffers(1, &bufferObject[INDEX_BUFFER]);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferObject[INDEX_BUFFER]);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, numIndices * sizeof(GLuint), indices, GL_STATIC_DRAW);
	}

	if (colours) { 
		glGenBuffers(1, &bufferObject[COLOUR_BUFFER]);
		glBindBuffer(GL_ARRAY_BUFFER, bufferObject[COLOUR_BUFFER]);
		glBufferData(GL_ARRAY_BUFFER, numVertices * sizeof(Vector4), colours, GL_STATIC_DRAW);
		glVertexAttribPointer(COLOUR_BUFFER, 4, GL_FLOAT, GL_FALSE, 0, 0);
		glEnableVertexAttribArray(COLOUR_BUFFER);
	}
	if (normals) {
		glGenBuffers(1, &bufferObject[NORMAL_BUFFER]);
		glBindBuffer(GL_ARRAY_BUFFER, bufferObject[NORMAL_BUFFER]);
		glBufferData(GL_ARRAY_BUFFER, numVertices * sizeof(Vector3), normals, GL_STATIC_DRAW);
		glVertexAttribPointer(NORMAL_BUFFER, 3, GL_FLOAT, GL_FALSE, 0, 0);
		glEnableVertexAttribArray(NORMAL_BUFFER);
	}

	glBindVertexArray(0);
}

void  Mesh::Draw() {
	glBindTexture(GL_TEXTURE_2D, texture);
	glBindVertexArray(arrayObject);
	if (bufferObject[INDEX_BUFFER]) {
		glDrawElements(type, numIndices, GL_UNSIGNED_INT, 0);
	}
	else {
		glDrawArrays(type, 0, numVertices);
	}
	glBindVertexArray(0);
	glBindTexture(GL_TEXTURE_2D, 0);
}

Mesh* Mesh::GenerateQuad() {
	Mesh* m = new  Mesh();
	m->numVertices = 4;
	m->type = GL_TRIANGLE_STRIP;
	
	m->vertices = new  Vector3[m->numVertices];
	m->textureCoords = new  Vector2[m->numVertices];
	m->colours = new  Vector4[m->numVertices];
	
	m->vertices[0] = Vector3(-1.0f, -1.0f, 0.0f);
	m->vertices[1] = Vector3(-1.0f, 1.0f, 0.0f);
	m->vertices[2] = Vector3(1.0f, -1.0f, 0.0f);
	m->vertices[3] = Vector3(1.0f, 1.0f, 0.0f);
	
	m->textureCoords[0] = Vector2(0.0f, 1.0f);
	m->textureCoords[1] = Vector2(0.0f, 0.0f);
	m->textureCoords[2] = Vector2(1.0f, 1.0f);
	m->textureCoords[3] = Vector2(1.0f, 0.0f);
	
	for (int i = 0; i < 4; ++i) {
		m->colours[i] = Vector4(1.0f, 1.0f, 1.0f, 1.0f);
	}

	m->BufferData();
	return m;
}




//create isosoheadron
Mesh* Mesh::GenerateIco() {

	Mesh* m = new Mesh();
	
	static GLfloat vdata[12][3] = {
		{ -X, 0.0, Z },{ X, 0.0, Z },{ -X, 0.0, -Z },{ X, 0.0, -Z },
		{ 0.0, Z, X },{ 0.0, Z, -X },{ 0.0, -Z, X },{ 0.0, -Z, -X },
		{ Z, X, 0.0 },{ -Z, X, 0.0 },{ Z, -X, 0.0 },{ -Z, -X, 0.0 }
	};
	static GLuint tindices[20][3] = {
		{ 0,4,1 },{ 0,9,4 },{ 9,5,4 },{ 4,5,8 },{ 4,8,1 },
		{ 8,10,1 },{ 8,3,10 },{ 5,3,8 },{ 5,2,3 },{ 2,7,3 },
		{ 7,10,3 },{ 7,6,10 },{ 7,11,6 },{ 11,0,6 },{ 0,1,6 },
		{ 6,1,10 },{ 9,0,11 },{ 9,11,2 },{ 9,2,5 },{ 7,2,11 } };
	int i;

	m->numIndices = 20 * 3;
	m->numVertices = 12;
	m->indices = new GLuint[20 * 3];

	for (i = 0; i < 20; i++) {
		/* color information here */
		m->indices[i * 3] = tindices[i][0];
		m->indices[i * 3 + 1] = tindices[i][1];
		m->indices[i * 3 + 2] = tindices[i][2];
	}

	m->vertices = new Vector3[12];
	for (i = 0; i < 12; i++) {
		/* color information here */
		memcpy(&m->vertices[i], vdata[i], sizeof(Vector3));
	}
	
	m->BufferData();
	
	

	return m;
}


//icosphere creation stuff starts here

//make index be 32bit unsigned int
using Index = std::uint32_t;

//define triangle to be made of 3 indexs
struct Triangle
{
	Index vertex[3];
};

//lists of triangels and vertexs
using TriangleList = std::vector<Triangle>;
using VertexList = std::vector<Vector3>;

//make icosahedron as before

	//list of points
	static const VertexList originalVertices =
	{
		{ -X,N,Z },{ X,N,Z },{ -X,N,-Z },{ X,N,-Z },
		{ N,Z,X },{ N,Z,-X },{ N,-Z,X },{ N,-Z,-X },
		{ Z,X,N },{ -Z,X, N },{ Z,-X,N },{ -Z,-X, N }
	};

	//list of triangles
	static const TriangleList originalTriangles =
	{
		{ 0,4,1 },{ 0,9,4 },{ 9,5,4 },{ 4,5,8 },{ 4,8,1 },
		{ 8,10,1 },{ 8,3,10 },{ 5,3,8 },{ 5,2,3 },{ 2,7,3 },
		{ 7,10,3 },{ 7,6,10 },{ 7,11,6 },{ 11,0,6 },{ 0,1,6 },
		{ 6,1,10 },{ 9,0,11 },{ 9,11,2 },{ 9,2,5 },{ 7,2,11 }
	};

	//make map to check not reusing indexs
	using check = std::map<std::pair<Index, Index>, Index>;

	//check the vertex hasnt been made alrdy and it is new then normalise it and add to list of vertices
	Index edgeVertex(check& check, VertexList& vertices, Index first, Index second) {
		check::key_type key(first, second);
		if (key.first > key.second) {
			std::swap(key.first, key.second);
		}

		auto inserted = check.insert({ key, vertices.size() });
		if (inserted.second)
		{
			Vector3 edge0 = vertices[first];
			Vector3 edge1 = vertices[second];
			Vector3 point = (edge0 + edge1);
			point.Normalise();
			vertices.push_back(point);
		}

		return inserted.first->second;
	}


	//method to subdivide triangels
	TriangleList subdivide(VertexList& vertices,TriangleList triangles)
	{
		//create a new check map
		check check;
		//create list of triangles
		TriangleList newTriangles;

		//for every triangle
		for (auto&& each : triangles)
		{
			//create an array of 3 indexs to store midpoints in
			std::array<Index, 3> midPoint;

			//for each edge on current triangle
			for (int edge = 0; edge < 3; ++edge) {
				//add new midpoints to the array
				midPoint[edge] = edgeVertex(check, vertices,each.vertex[edge], each.vertex[(edge + 1) % 3]);
			}

			//add the 4 new triangles to the triangel list
			newTriangles.push_back({ each.vertex[0], midPoint[0], midPoint[2] });
			newTriangles.push_back({ each.vertex[1], midPoint[1], midPoint[0] });
			newTriangles.push_back({ each.vertex[2], midPoint[2], midPoint[1] });
			newTriangles.push_back({ midPoint[0], midPoint[1], midPoint[2] });
		}
		//return the new triangels
		return newTriangles;
	}

	//make indexed mesh a pair of vertexs/triangels
	using IndexedMesh = std::pair<VertexList, TriangleList>;

	//define the icosphere as an indexed mesh of a certain sub divisions
	IndexedMesh icosphere(int subdivisions)
	{
		VertexList vertices = originalVertices;
		TriangleList triangles = originalTriangles;

		for (int i = 0; i<subdivisions; ++i)
		{
			triangles = subdivide(vertices, triangles);
		}

		//add noise to each vertex
		/*
		Noise n = Noise();
		for (auto&& each : vertices) {
			n.getHeight(each);
		}
		*/
		//retrun the lists of vertices and triangles
		return{ vertices, triangles };
	}

	//method to send the icosphere to renderer
	Mesh* Mesh::GenerateIcosphere(int levels){
		IndexedMesh finalGeom = icosphere(levels);
		//output for help with debug
		cout << "New mesh generated with: \n";
		cout << "	number of triangles: " << finalGeom.second.size() << "\n";
		cout << "	number of vertexs: " << finalGeom.first.size() << "\n";
		

		Mesh* m = new Mesh();
		
		m->type = GL_PATCHES;
		m->numIndices = finalGeom.second.size() * 3;
		m->numVertices = finalGeom.first.size();
		m->indices = new GLuint[m->numIndices];
		m->vertices = new Vector3[m->numVertices];
		//m->textureCoords = new Vector2[m->numVertices];
		
		int i; 

		for (i = 0; i < ((m->numIndices)/3); i++) {	
			m->indices[i * 3] = finalGeom.second[i].vertex[0];
			m->indices[i * 3 + 1] = finalGeom.second[i].vertex[1];
			m->indices[i * 3 + 2] = finalGeom.second[i].vertex[2];
		}

	
		for (i = 0; i < m->numVertices; i++) {
			m->vertices[i].x = finalGeom.first[i].x;
			m->vertices[i].y = finalGeom.first[i].y;
			m->vertices[i].z = finalGeom.first[i].z;
			//texture coord by chaging xyz into uv coordinates
			/*
			m->textureCoords[i] = Vector2((0.5f + atan2(finalGeom.first[i].x, finalGeom.first[i].z) / (2 * PI)),
				(0.5f - asin(finalGeom.first[i].y/ finalGeom.first[i].Length()) / PI));
			*/
		}

		m->GenerateNormals();
		
		m->BufferData();
		return m;
	}
