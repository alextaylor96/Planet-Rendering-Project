#pragma  once
#include "OGLRenderer.h"

enum  MeshBuffer {
	VERTEX_BUFFER, COLOUR_BUFFER, TEXTURE_BUFFER, INDEX_BUFFER,  NORMAL_BUFFER, MAX_BUFFER
};

class  Mesh {
public:
	Mesh(void);
	~Mesh(void);
	virtual  void    Draw();
	static  Mesh*    GenerateTriangle();
	static  Mesh*    GenerateTriangleStrips();
	static  Mesh*    GenerateIco();
	static  Mesh*    GenerateIcosphere(int);
	static Mesh* GenerateQuad();
	void      SetTexture(GLuint  tex) { texture = tex; }
	GLuint    GetTexture() { return  texture; }
	
	

protected:
	void      BufferData();
	GLuint    arrayObject;
	GLuint    bufferObject[MAX_BUFFER];
	GLuint    numVertices;
	GLuint    numIndices;
	GLuint    type;
	Vector3*     vertices;
	unsigned  int*   indices;
	Vector4*     colours;
	GLuint        texture;
	Vector2*     textureCoords;	
	void          GenerateNormals();
	Vector3*     normals;

};