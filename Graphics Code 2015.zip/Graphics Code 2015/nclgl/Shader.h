#pragma once

#include "OGLRenderer.h"

#define SHADER_VERTEX   0
#define SHADER_FRAGMENT 1
#define SHADER_GEOMETRY 2
#define SHADER_TCS 3
#define SHADER_TES 4
#define SHADER_MAX 5

using namespace std;
class Shader	{
public:
	Shader(string vertex, string fragment , string geometry = "", string tcsFile = "", string tesFile = "");
	~Shader(void);

	GLuint  GetProgram() { return program;}
	bool	LinkProgram();

protected:
	bool	LoadShaderFile(string from, string &into);
	GLuint	GenerateShader(string from, GLenum type);
	void	SetDefaultAttributes();

	GLuint objects[SHADER_MAX];
	GLuint program;

	bool loadFailed;
};

